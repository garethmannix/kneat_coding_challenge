﻿// ***********************************************************************
// Assembly         : SharpTrooper
// Author           : Gareth Mannix
// Created          : 04-08-2018
//
// Last Modified By : Gareth Mannix
// Last Modified On : 04-08-2018
// ***********************************************************************
// <copyright file="StarshipEnquirer.cs" company="Olcay Bayram">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpTrooper.Entities
{
    /// <summary>
    /// Class StarshipEnquirer.
    /// A static class containing methods that can be used to quriey various apecsts of a Starship.
    /// </summary>
    public static class StarshipEnquirer
    {
        /// <summary>
        /// Enumeration representing the number of Hours in Day, Week, Month and Year. 
        /// </summary>
        private enum Hours
        {
            None = 0,
            Day = 24,
            Week = 168,
            Month = 672,
            Year = 8064
        }


        /// <summary>
        /// Calculates the number of resupply stops required for given distance.
        /// </summary>
        /// <param name="starship">The starship.</param>
        /// <param name="distanceInMglt">The distance in MGLT.</param>
        /// <returns>System.Int32.</returns>
        public static int CalculateNumberOfResupplyStops(Starship starship, int distanceInMglt)
        {
            //GM: Can MGLT be zero? This is ambiguous, probably not. 
            //TODO:GM: Confirm that MGLT cannot be zero
            return distanceInMglt / (ConsumablesToHours(starship) * starship.MGLT/*hours*/);
        }

        /// <summary>
        /// Converts Consumables to hours format.
        /// </summary>
        /// <param name="starship">The starship.</param>
        /// <returns>System.Int32.</returns>
        public static int ConsumablesToHours(Starship starship)
        {
            int consumableQuantity;
            string consumables = starship.consumables;

            var result = int.TryParse(new string(consumables.Where(Char.IsDigit).ToArray()),
                out consumableQuantity);

            if(!result)
                throw new Exception("Unable to parse consumable quantity");

            Hours hours = Hours.None;
            if (consumables.Contains(Hours.Day.ToString().ToLower()))
            {
                hours = Hours.Day;
            }
            else if (starship.consumables.Contains(Hours.Week.ToString().ToLower()))
            {
                hours = Hours.Week;
            }
            else if (consumables.Contains(Hours.Month.ToString().ToLower()))
            {
                hours = Hours.Month;
            }
            else if (consumables.Contains(Hours.Year.ToString().ToLower()))
            {
                hours = Hours.Year;
            }
            if(hours == Hours.None)
                throw new Exception("Unable to parse consumable duration");

            return consumableQuantity * (int)hours;
        }
        
    }
}
