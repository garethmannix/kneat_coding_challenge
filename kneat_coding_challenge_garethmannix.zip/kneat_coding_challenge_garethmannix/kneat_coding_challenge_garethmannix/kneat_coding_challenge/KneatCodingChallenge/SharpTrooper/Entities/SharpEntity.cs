﻿namespace SharpTrooper.Entities
{
    public abstract class SharpEntity
    {
    }
}