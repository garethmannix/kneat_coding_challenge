﻿// ***********************************************************************
// Assembly         : SharpTrooperTests
// Author           : Gareth Mannix
// Created          : 04-08-2018
//
// Last Modified By : Gareth Mannix
// Last Modified On : 04-08-2018
// ***********************************************************************
// <copyright file="StarshipEnquirerTests.cs" company="">
//     Copyright ©  2018
// </copyright>
// <summary></summary>
// ***********************************************************************
using NUnit.Framework;
using SharpTrooper.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SharpTrooper.Core;


namespace SharpTrooper.Entities.Tests
{
    /// <summary>
    /// Class StarshipEnquirerTests.
    /// </summary>
    [TestFixture()]
    public class StarshipEnquirerTests
    {
        private Starship _mockMFalcon;
        private Starship _mockYWing;
        private Starship _dudStarship; 

        [SetUp]
        public void Setup()
        {
            //Mock object values taken from the SWAPI results https://swapi.co/
            //Valid on: 08/04/18
            _mockMFalcon = new Starship()
            {
                MGLT = 75,
                consumables = "2 months"
            };

            _mockYWing = new Starship()
            {
                MGLT = 80,
                consumables = "1 week"
            };
            _dudStarship = new Starship()
            {
                MGLT = 10,
                consumables = " mins"
            };
        }

        [Test()]
        public void CalculateNumberOfResupplyStopsTest()
        {
            int distance = 1000000;//example input provided by kneat
            int expected = 9;//example value provided by kneat
            Assert.AreEqual(expected,
                StarshipEnquirer.CalculateNumberOfResupplyStops(_mockMFalcon, distance));

            expected = 74;//example value provided by kneat
            Assert.AreEqual(expected,
                StarshipEnquirer.CalculateNumberOfResupplyStops(_mockYWing, distance));
        }

        [Test()]
        public void ConsumablesToHoursTest()
        {
            var expected = 1344;//The number of hours in 2 months
            var result = StarshipEnquirer.ConsumablesToHours(_mockMFalcon);
            Assert.AreEqual(expected, result);

            expected = 168;//The number of hours in a week
            result = StarshipEnquirer.ConsumablesToHours(_mockYWing);
            Assert.AreEqual(expected, result);
        }

        [Test()]
        public void ExceptionTest()
        {
            //We could check for specfic exception messages but this will do for now.
            Assert.Throws<Exception>(() =>
                { StarshipEnquirer.CalculateNumberOfResupplyStops(_dudStarship, 123);});
        }

        [Test()]
        public void SimpleIntegrationTest()
        {
            SharpTrooper.Core.SharpTrooperCore core = new SharpTrooperCore();
            Starship mFalcon = core.GetStarship("10");
            string expectedStarShip = "Millennium Falcon";
            //Make sure we have the right Starship
            Assert.True(expectedStarShip == mFalcon.name);

            int distance = 1000000;//example input provided by kneat
            int expectedResupplyStops = 9;//example value provided by kneat
            Assert.AreEqual(expectedResupplyStops, 
                StarshipEnquirer.CalculateNumberOfResupplyStops(mFalcon, distance));
        }
    }
}