﻿// ***********************************************************************
// Assembly         : KneatCodingChallengeConsoleApplication
// Author           : Gareth Mannix
// Created          : 04-08-2018
//
// Last Modified By : Gareth Mannix
// Last Modified On : 04-08-2018
// ***********************************************************************
// <copyright file="Program.cs" company="">
//     Copyright ©  2018
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SharpTrooper.Core;
using SharpTrooper.Entities;

namespace KneatCodingChallengeConsoleApplication
{
    /// <summary>
    /// Class Program.
    /// </summary>
    class Program
    {
        /// <summary>
        /// Defines the entry point of the application.
        /// </summary>
        /// <param name="args">The arguments.</param>
        static void Main(string[] args)
        {
            SharpTrooper.Core.SharpTrooperCore core = new SharpTrooperCore();
            SharpEntityResults<Starship> starships;
            try
            {
                starships = core.GetAllStarships();
            }
            catch (Exception)
            {
                Console.WriteLine("HTTP request failed.\nPlease ensure Python and Curl have been installed.");
                Console.ReadLine();
                return;
            }
            //Display weclome message if the connection request is successful.
            Console.WriteLine("Welcome to SharpTrooper, the Starship resupply calculator");

            bool exitApp = false;
            while (!exitApp)
            {
                Console.Write("Please enter distance in MGLT, 'x' to exit: ");
                var consoleInput = Console.ReadLine();
                var mglt = 0;
                if (int.TryParse(consoleInput, out mglt))
                {
                    foreach (Starship ss in starships.results)
                    {
                        string resupplyStops = "";
                        try
                        {
                           resupplyStops = StarshipEnquirer.CalculateNumberOfResupplyStops(ss, mglt).ToString();
                        }
                        catch (Exception e)
                        {
                            resupplyStops = e.Message;
                        }

                        Console.WriteLine(ss.name + " " + resupplyStops);
                    }
                    Console.WriteLine("\n");
                }
                else//handle failed parsed the input
                {
                    //We must check that the user simply did hit the eneter key.
                    //Possible empty string if so.
                    if (!string.IsNullOrEmpty(consoleInput))
                        if (consoleInput.Contains("x") || consoleInput.Contains("X"))
                            exitApp = true;
                }

            }//end while
        }
    }
}
